package main

import (
	"context"
	"encoding/json"
	"fmt"
	"image/color"
	"sort"
	"strconv"
	"strings"
	"time"

	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/canvas"
	"fyne.io/fyne/v2/container"
	"fyne.io/fyne/v2/dialog"
	"fyne.io/fyne/v2/storage"
	"fyne.io/fyne/v2/theme"
	"fyne.io/fyne/v2/widget"

	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/ethclient"
	core "github.com/ligun0805/bundle-rescue/internal/bundlecore"
)

var (
	runCtx context.Context
	runCancel context.CancelFunc
	viewWin fyne.Window
	logWin  fyne.Window
	logBox  *widget.Entry
	logProg *widget.ProgressBar
	logProgLbl *widget.Label
	logScroll *container.Scroll

	viewFilter *widget.Entry
	viewSort   *widget.Select
	viewAsc    *widget.Check
	viewIdx    []int

	statsAdded     int
	statsSimulated int
	statsRescued   int

	pairs []pairRow
	table *widget.Table
)

func ensureLogWindow(a fyne.App) fyne.Window {
	if logWin != nil { return logWin }
	logWin = a.NewWindow("Logs")	
	logWin.SetOnClosed(func(){ logWin = nil })
	logProg = widget.NewProgressBar()
	logProgLbl = widget.NewLabel("")
	exportBtn := widget.NewButtonWithIcon("Export Telemetry JSON", theme.DocumentSaveIcon(), func(){
		saveTelemetryJSON(logWin)
	})
	top := container.NewBorder(nil, nil, nil, exportBtn, container.NewHBox(widget.NewLabel("Progress:"), logProg, logProgLbl))
	bg := canvas.NewLinearGradient(color.NRGBA{12,16,24,255}, color.NRGBA{20,28,40,255}, 90)
	logBox = widget.NewMultiLineEntry()
    logBox.Disable()
    logBox.Wrapping = fyne.TextWrapWord
    logScroll = container.NewVScroll(logBox)
    logScroll.SetMinSize(fyne.NewSize(800, 180))
    // Используем top и bg, чтобы не было «declared and not used», и заодно красивый фон
    logWin.SetContent(container.NewBorder(top, nil, nil, nil, container.NewMax(bg, logScroll)))
	logWin.Resize(fyne.NewSize(1000, 700))
	return logWin
}
func appendLogLine(a fyne.App, s string) {
    w := ensureLogWindow(a)
    // обновляем напрямую — без Driver().RunOnMain/CallOnMain (совместимо с твоей Fyne)
    logBox.SetText(logBox.Text + time.Now().Format("15:04:05 ") + s + "\n")
    if logScroll != nil { logScroll.ScrollToBottom() }
    w.Canvas().Refresh(logBox)
}

func saveTelemetryJSON(w fyne.Window) {
	d := dialog.NewFileSave(func(wc fyne.URIWriteCloser, err error){
		if err!=nil || wc==nil { return }
		defer wc.Close()
		out := map[string]any{
			"generatedAt": time.Now().UTC().Format(time.RFC3339),
			"telemetry": telemetry,
		}
		enc := json.NewEncoder(wc); enc.SetIndent("", "  "); _ = enc.Encode(out)
	}, w)
	d.SetFileName("telemetry.json")
	d.SetFilter(storage.NewExtensionFileFilter([]string{".json"}))
	d.Show()
}

func openViewPairsWindow(a fyne.App, rpc string) {
    defer func() {
        if r := recover(); r != nil {
            w := viewWin
            if w == nil { w = ensureLogWindow(a) }
            dialog.ShowError(fmt.Errorf("%v", r), w)
        }
    }()
    if viewWin == nil {
        viewWin = a.NewWindow("View Pairs")
        viewWin.SetOnClosed(func(){ viewWin = nil })
    }
    // если пар нет — покажем заглушку и всё равно откроем окно
    if len(pairs) == 0 {
        viewWin.SetContent(container.NewCenter(widget.NewLabel("No pairs loaded yet")))
        viewWin.Resize(fyne.NewSize(720, 480))
        viewWin.Show()
        return
    }
    // ---- Улучшенный экран: хедер, фильтр/сортировка, зебра и Actions ----
    const (
        colToken = iota
        colFrom
        colTo
        colAmtTok
        colAmtWei
        colDec
        colActions
        colCount
    )
	
	// ЕДИНЫЕ ширины колонок — используем для header, controls и самой таблицы
    const (
        wToken   = 140
        wFrom    = 190
        wTo      = 190
        wAmtTok  = 120
        wAmtWei  = 180
        wDec     = 60
        wActions = 172
    )


    // Панель фильтра/сортировки
    if viewFilter == nil { viewFilter = widget.NewEntry() }
    viewFilter.SetPlaceHolder("Filter by token/from/to…")
    if viewSort == nil {
        viewSort = widget.NewSelect([]string{"Token","From","To","Amount","Decimals"}, func(string) {})
        viewSort.SetSelected("Token")
    }
    if viewAsc == nil { viewAsc = widget.NewCheck("Asc", func(bool){}) }
    viewAsc.SetChecked(true)

    // Хедер: прямоугольники с теми же minSize, что у колонок таблицы
    makeHeadCell := func(text string, w int, align fyne.TextAlign) fyne.CanvasObject {
        r := canvas.NewRectangle(color.NRGBA{R:32,G:40,B:52,A:255}); r.SetMinSize(fyne.NewSize(float32(w), 34))
        lbl := widget.NewLabelWithStyle(text, align, fyne.TextStyle{Bold:true})
        return container.NewMax(r, container.NewPadded(lbl))
    }
    headerWrap := container.NewHBox(
        makeHeadCell("Token",   wToken,   fyne.TextAlignLeading),
        makeHeadCell("From",    wFrom,    fyne.TextAlignLeading),
        makeHeadCell("To",      wTo,      fyne.TextAlignLeading),
        makeHeadCell("Amount (tokens)", wAmtTok, fyne.TextAlignTrailing),
        makeHeadCell("Wei",     wAmtWei,  fyne.TextAlignTrailing),
        makeHeadCell("Dec",     wDec,     fyne.TextAlignCenter),
        makeHeadCell("Actions", wActions, fyne.TextAlignCenter),
    )

    // Индекс отображаемых строк
    rebuildViewIdx()
    onChange := func() {
        rebuildViewIdx()
        if table != nil { table.Refresh() }
    }
    viewFilter.OnChanged = func(string){ onChange() }
    viewSort.OnChanged   = func(string){ onChange() }
    viewAsc.OnChanged    = func(bool){ onChange() }

    // Таблица
    table = widget.NewTable(
        func() (int, int) { return len(viewIdx), colCount },
        func() fyne.CanvasObject {
            // Фоновая зебра + контент: либо Label, либо Actions (Edit/Delete)
            bg := canvas.NewRectangle(color.Transparent)
            bg.SetMinSize(fyne.NewSize(0, 28))
            lbl := widget.NewLabel("")
            lbl.Truncation = fyne.TextTruncateEllipsis
            lbl.Wrapping   = fyne.TextWrapOff
            editBtn := widget.NewButton("Edit", nil);  editBtn.Importance = widget.LowImportance
            delBtn  := widget.NewButton("Delete", nil); delBtn.Importance  = widget.LowImportance
            actions := container.NewHBox(editBtn, delBtn)
            // Не скрываем по умолчанию — в апдейтере переключим видимость для нужных колонок.
            return container.NewMax(bg, container.NewPadded(lbl), container.NewPadded(actions))
        },
        func(id widget.TableCellID, obj fyne.CanvasObject) {
            if id.Row < 0 || id.Row >= len(viewIdx) { return }
            pr := pairs[viewIdx[id.Row]]

            c := obj.(*fyne.Container)
            bg := c.Objects[0].(*canvas.Rectangle)
            padLbl := c.Objects[1].(*fyne.Container)
            lbl := padLbl.Objects[0].(*widget.Label)
            padAct := c.Objects[2].(*fyne.Container)
            actBox := padAct.Objects[0].(*fyne.Container)
            editBtn := actBox.Objects[0].(*widget.Button)
            delBtn  := actBox.Objects[1].(*widget.Button)

            // Зебра
            if id.Row%2 == 0 { bg.FillColor = color.NRGBA{R:22,G:26,B:34,A:255} } else { bg.FillColor = color.NRGBA{R:16,G:20,B:28,A:255} }

            switch id.Col {
            case colToken:
                padAct.Hide(); padLbl.Show(); padLbl.Refresh(); padAct.Refresh()
                lbl.Alignment = fyne.TextAlignLeading
                lbl.SetText(pr.Token)
            case colFrom:
                padAct.Hide(); padLbl.Show(); padLbl.Refresh(); padAct.Refresh()
                lbl.Alignment = fyne.TextAlignLeading
                lbl.SetText(shortAddr(pr.From))
            case colTo:
                padAct.Hide(); padLbl.Show(); padLbl.Refresh(); padAct.Refresh()
                lbl.Alignment = fyne.TextAlignLeading
                lbl.SetText(shortAddr(pr.To))
            case colAmtTok:
                padAct.Hide(); padLbl.Show(); padLbl.Refresh(); padAct.Refresh()
                lbl.Alignment = fyne.TextAlignTrailing
                lbl.SetText(pr.AmountTokens)
            case colAmtWei:
                padAct.Hide(); padLbl.Show(); padLbl.Refresh(); padAct.Refresh()
                lbl.Alignment = fyne.TextAlignTrailing
                lbl.SetText(pr.AmountWei)
            case colDec:
                padAct.Hide(); padLbl.Show(); padLbl.Refresh(); padAct.Refresh()
                lbl.Alignment = fyne.TextAlignCenter
                lbl.SetText(fmt.Sprintf("%d", pr.Decimals))
            case colActions:
                padLbl.Hide(); padAct.Show(); padLbl.Refresh(); padAct.Refresh()
                row := viewIdx[id.Row]
                editBtn.OnTapped = func() {
                    // форма уже есть — buildEditForm; по onChange пересохраняем и рефрешим
                    form := buildEditForm(&pairs[row], func(){
                        saveQueueToFile()
                        rebuildViewIdx()
                        table.Refresh()
                    })
                    dialog.ShowCustom("Edit Pair", "Close", form, viewWin)
                }
                delBtn.OnTapped = func() {
                    dialog.ShowConfirm("Delete Pair", "Remove this row from the queue?", func(ok bool){
                        if !ok { return }
                        // удалить по исходному индексу
                        pairs = append(pairs[:row], pairs[row+1:]...)
                        saveQueueToFile()
                        rebuildViewIdx()
                        table.Refresh()
                    }, viewWin)
                }
            }
            bg.Refresh(); c.Refresh()
        },
    )
    // Ширины колонок — отрегулируй под себя при желании
    table.SetColumnWidth(colToken,   wToken)
    table.SetColumnWidth(colFrom,    wFrom)
    table.SetColumnWidth(colTo,      wTo)
    table.SetColumnWidth(colAmtTok,  wAmtTok)
    table.SetColumnWidth(colAmtWei,  wAmtWei)
    table.SetColumnWidth(colDec,     wDec)
    table.SetColumnWidth(colActions, wActions)

    // Верхняя панель: хедер + фильтр/сортировка с выравниванием по тем же колонкам
    // фильтр занимает первые 3 колонки; select — колонку Amount; Asc — колонку Wei; справа — Dec+Actions как пустышки
    filterWrap := func(obj fyne.CanvasObject, w int) fyne.CanvasObject {
        r := canvas.NewRectangle(color.Transparent); r.SetMinSize(fyne.NewSize(float32(w), 36))
        return container.NewMax(r, container.NewPadded(obj))
    }
    controls := container.NewHBox(
        filterWrap(viewFilter, wToken+wFrom+wTo),
        filterWrap(viewSort,   wAmtTok),
        filterWrap(viewAsc,    wAmtWei),
        filterWrap(widget.NewLabel(""), wDec+wActions),
    )
    top := container.NewVBox(headerWrap, controls)

    bg := canvas.NewLinearGradient(color.NRGBA{12,16,24,255}, color.NRGBA{20,28,40,255}, 90)
    body := container.NewMax(bg, table)
    viewWin.SetContent(container.NewBorder(top, nil, nil, nil, body))
    viewWin.Resize(fyne.NewSize(980, 620))
    viewWin.Show()
}

// Короткое отображение адреса 0x1234…abcd
func shortAddr(s string) string {
    if len(s) <= 16 { return s }
    return s[:10] + "…" + s[len(s)-6:]
}


func rebuildViewIdx() {
	q := strings.ToLower(strings.TrimSpace(viewFilter.Text))
	viewIdx = viewIdx[:0]
	for i, p := range pairs {
		if q == "" || strings.Contains(strings.ToLower(p.Token), q) || strings.Contains(strings.ToLower(p.From), q) || strings.Contains(strings.ToLower(p.To), q) {
			viewIdx = append(viewIdx, i)
		}
	}
	key := viewSort.Selected
	asc := viewAsc.Checked
	sort.SliceStable(viewIdx, func(i, j int) bool {
		a := pairs[viewIdx[i]]
		b := pairs[viewIdx[j]]
		var less bool
		switch key {
		case "From":
			less = strings.ToLower(a.From) < strings.ToLower(b.From)
		case "To":
			less = strings.ToLower(a.To) < strings.ToLower(b.To)
		case "Amount":
			less = strings.TrimLeft(a.AmountWei, "0") < strings.TrimLeft(b.AmountWei, "0")
		case "Decimals":
			less = a.Decimals < b.Decimals
		default:
			less = strings.ToLower(a.Token) < strings.ToLower(b.Token)
		}
		if asc { return less }
		return !less
	})
}

func openAddPairWindow(a fyne.App, rpc string) {
	win := a.NewWindow("Add Pair")
	win.SetOnClosed(func(){ /* ничего, окно одноразовое */ })
	tokenE := widget.NewEntry()
	fromE := widget.NewEntry()
	fromPkE := widget.NewPasswordEntry()
	toE := widget.NewEntry()
	amountTokE := widget.NewEntry()
	decE := widget.NewEntry()
	status := widget.NewLabel("")
	status.Wrapping = fyne.TextWrapWord
	statusCard := widget.NewCard("Status", "", status)

	fromPreview := widget.NewLabel("")
	fromPkE.OnChanged = func(s string){
		addr, err := deriveAddrFromPK(s)
		if err != nil { fromPreview.SetText("from: <invalid privkey>"); fromPreview.TextStyle = fyne.TextStyle{Bold:true}; return }
		fromPreview.TextStyle = fyne.TextStyle{}; fromPreview.SetText("from: " + addr)
		if strings.TrimSpace(fromE.Text)=="" { fromE.SetText(addr) }
	}

	checkBtn := widget.NewButtonWithIcon("CHECK", theme.SearchIcon(), func(){
		go func(){
			ec, err := ethclient.Dial(rpc); if err != nil { status.SetText("RPC dial: "+err.Error()); return }
			token := strings.TrimSpace(tokenE.Text)
			if !common.IsHexAddress(token) { status.SetText("Token address invalid"); return }
			from := strings.TrimSpace(fromE.Text)
			if from=="" && strings.TrimSpace(fromPkE.Text)!="" {
				if addr,err := deriveAddrFromPK(fromPkE.Text); err==nil { from = addr; fromE.SetText(addr) }
			}
			if !common.IsHexAddress(from) { status.SetText("From address invalid (derive from PK?)"); return }
			dec, err := fetchTokenDecimals(ec, common.HexToAddress(token)); if err!=nil { status.SetText("decimals: "+err.Error()); return }
			bal, err := fetchTokenBalance(ec, common.HexToAddress(token), common.HexToAddress(from)); if err!=nil { status.SetText("balance: "+err.Error()); return }
			// Проверка paused через core.CheckPaused
			ctx, cancel := context.WithTimeout(context.Background(), 8*time.Second); defer cancel()
			known, paused, _ := core.CheckPaused(ctx, ec, common.HexToAddress(token))
			pausedLine := "Not pausable"
			if known { if paused { pausedLine = "PAUSED: yes" } else { pausedLine = "PAUSED: no" } }
			// Префлайт transfer(), если заполнены To и Amount
			xferLine := "Transferable: enter To & Amount to test"
			toAddr := strings.TrimSpace(toE.Text)
			if common.IsHexAddress(toAddr) && strings.TrimSpace(amountTokE.Text) != "" {
				if w, e := toWeiFromTokens(amountTokE.Text, dec); e == nil {
					ok, reason, _ := core.PreflightTransfer(ctx, ec, common.HexToAddress(token), common.HexToAddress(from), common.HexToAddress(toAddr), w)
					if ok { xferLine = "Transferable: yes" } else { xferLine = "Transferable: no (" + reason + ")" }
				} else {
					xferLine = "Transferable: amount invalid"
				}
			}
			msg := fmt.Sprintf("Decimals: %d\nBalance (wei): %s\nBalance (tokens): %s\n%s\n%s",
				dec, bal.String(), formatTokensFromWei(bal, dec), pausedLine, xferLine)
			status.SetText(msg)
			if decE.Text=="" { decE.SetText(strconv.Itoa(dec)) }
		}()
	})
	saveBtn := widget.NewButtonWithIcon("SAVE", theme.DocumentSaveIcon(), func(){
		token := strings.TrimSpace(tokenE.Text)
		from := strings.TrimSpace(fromE.Text)
		fromPk := strings.TrimSpace(fromPkE.Text)
		to := strings.TrimSpace(toE.Text)
		amountTok := strings.TrimSpace(amountTokE.Text)
		dec := atoi(decE.Text, -1)
		if token=="" || to=="" || fromPk=="" || amountTok=="" { status.SetText("Fill required fields"); return }
		if from=="" {
			if addr,err := deriveAddrFromPK(fromPk); err==nil { from = addr } else { status.SetText("Cannot derive From from PK"); return }
		}
		if !common.IsHexAddress(token) || !common.IsHexAddress(from) || !common.IsHexAddress(to) {
			status.SetText("addresses invalid"); return
		}
		if dec < 0 { dec = 18 }
		ec, err := ethclient.Dial(rpc); if err != nil { status.SetText("RPC dial: "+err.Error()); return }
		w, err := toWeiFromTokens(amountTok, dec); if err!=nil { status.SetText("amount: "+err.Error()); return }
		bal, err := fetchTokenBalance(ec, common.HexToAddress(token), common.HexToAddress(from)); if err!=nil { status.SetText("balance: "+err.Error()); return }
		if bal.Cmp(w) < 0 { status.SetText("Rejected: balance < amount"); return }
		// Блокируем сохранение, если токен в паузе (распознан)
		ctx, cancel := context.WithTimeout(context.Background(), 6*time.Second); defer cancel()
		if known, paused, _ := core.CheckPaused(ctx, ec, common.HexToAddress(token)); known && paused {
			status.SetText("Rejected: token is PAUSED"); return
		}
		// Блокируем сохранение, если transfer() ревертится на заданных параметрах
		if ok, reason, _ := core.PreflightTransfer(ctx, ec, common.HexToAddress(token), common.HexToAddress(from), common.HexToAddress(to), w); !ok {
			status.SetText("Rejected: token not transferable (" + reason + ")"); return
		}
		pairs = append(pairs, pairRow{ Token: token, From: from, FromPK: fromPk, To: to, AmountTokens: amountTok, AmountWei: w.String(), Decimals: dec, BalanceWei: bal.String(), BalanceTokens: formatTokensFromWei(bal, dec) })
		statsAdded++
		saveQueueToFile()
		status.SetText("Saved to queue ✔")
		// Закрываем окно после успешного сохранения
		win.Close()
	})
	cancelBtn := widget.NewButton("Cancel", func(){ win.Close() })

	form := widget.NewForm(
		widget.NewFormItem("Token", tokenE),
		widget.NewFormItem("From", fromE),
		widget.NewFormItem("From PK", fromPkE),
		widget.NewFormItem("To", toE),
		widget.NewFormItem("Amount (tokens)", amountTokE),
		widget.NewFormItem("Decimals", decE),
		widget.NewFormItem("", container.NewHBox(checkBtn, saveBtn, cancelBtn)),
	)
	win.SetContent(container.NewVBox(form, statusCard))
	win.Resize(fyne.NewSize(560, 520))
	win.Show()
}

func buildEditForm(p *pairRow, onChange func()) fyne.CanvasObject {
	token := widget.NewEntry(); token.SetText(p.Token)
	from := widget.NewEntry(); from.SetText(p.From)
	fromPk := widget.NewPasswordEntry(); fromPk.SetText(p.FromPK)
	to := widget.NewEntry(); to.SetText(p.To)
	amountTok := widget.NewEntry(); amountTok.SetText(p.AmountTokens)
	dec := widget.NewEntry(); if p.Decimals >= 0 { dec.SetText(fmt.Sprintf("%d", p.Decimals)) }
	status := widget.NewLabel("")
	form := widget.NewForm(
		widget.NewFormItem("Token", token),
		widget.NewFormItem("From", from),
		widget.NewFormItem("From PK", fromPk),
		widget.NewFormItem("To", to),
		widget.NewFormItem("Amount (tokens)", amountTok),
		widget.NewFormItem("Decimals", dec),
		widget.NewFormItem("", status),
	)
	form.SubmitText = "Save"
	form.OnSubmit = func(){
		if token.Text=="" || fromPk.Text=="" || to.Text=="" || amountTok.Text=="" { status.SetText("Fill required fields"); return }
		addr, err := deriveAddrFromPK(fromPk.Text); if err!=nil { status.SetText("Invalid From PK"); return }
		fromAddr := from.Text; if strings.TrimSpace(fromAddr)=="" { fromAddr = addr }
		d := -1; if strings.TrimSpace(dec.Text)!="" { if n,err := strconv.Atoi(dec.Text); err==nil { d = n } }
		if d < 0 { d = 18 }
		w, err := toWeiFromTokens(amountTok.Text, d); if err!=nil { status.SetText("amount: "+err.Error()); return }
		p.Token = token.Text; p.From = fromAddr; p.FromPK = fromPk.Text; p.To = to.Text; p.AmountTokens = amountTok.Text; p.Decimals = d; p.AmountWei = w.String()
		onChange()
	}
	return form
}

func simAndSendOne(a fyne.App, pr pairRow, rpc string) {
	appendLogLine(a, "Sim+Send one: token="+short(pr.Token)+" from="+short(pr.From)+" to="+short(pr.To))
	// unified path: mass runner handles the logic; here we can call it with a single pair in future
}

func runAll(a fyne.App, simOnly bool, rpc, chain, relays, auth, safe, blocksS, tipS, tipMulS, baseMulS, bufferS string) {
	// Не даём упасть всему приложению даже при панике внутри раннера
    defer func() {
        if r := recover(); r != nil {
            appendLogLine(a, fmt.Sprintf("[panic] %v", r))
        }
    }()
	if len(pairs)==0 { appendLogLine(a, "no pairs"); return }
	ec, err := ethclient.Dial(rpc); if err!=nil { appendLogLine(a, fmt.Sprintf("dial err: %v", err)); return }
	runCtx, runCancel = context.WithCancel(context.Background())
	ctx := runCtx
	total := len(pairs)
    // Окно логов нужно создать ПЕРЕД работой с прогресс-баром
    ensureLogWindow(a).Show()
    if logProg != nil {
        logProg.Min = 0
        logProg.Max = float64(total)
        logProg.SetValue(0)
    }
    if logProgLbl != nil {
        logProgLbl.SetText(fmt.Sprintf("0/%d", total))
    }
	for i, pr := range pairs {
		select { case <-ctx.Done(): appendLogLine(a, "STOP pressed — cancelling"); return; default: }
		appendLogLine(a, fmt.Sprintf("=== %s ALL: pair %d/%d ===", map[bool]string{true:"Simulate", false:"Run"}[simOnly], i+1, len(pairs)))
		p := core.Params{
			RPC: rpc, ChainID: mustBig(chain), Relays: strings.Split(relays, ","), AuthPrivHex: auth,
			Token: common.HexToAddress(pr.Token), From: common.HexToAddress(pr.From), To: common.HexToAddress(pr.To),
			AmountWei: mustBig(pr.AmountWei), SafePKHex: safe, FromPKHex: pr.FromPK,
			Blocks: atoi(blocksS, 6), TipGweiBase: atoi64(tipS, 3), TipMul: atof(tipMulS, 1.25), BaseMul: atoi64(baseMulS, 2), BufferPct: atoi64(bufferS, 5),
			SimulateOnly: simOnly, SkipIfPaused: true,
			Logf: func(f string, a2 ...any){ appendLogLine(a, fmt.Sprintf(f, a2...)) },
			OnSimResult: func(relay, raw string, ok bool, err string){
				telAdd(TelemetryItem{ Time: time.Now().UTC().Format(time.RFC3339), Action:"eth_callBundle", PairIndex:i, Relay: relay, OK: ok, Error: err, Raw: raw })
				if simOnly { statsSimulated++ }
			},
		}
		out, err := core.Run(ctx, ec, p)
		if err != nil { appendLogLine(a, "error: "+err.Error()) } else {
			appendLogLine(a, "result: " + out.Reason)
			if out.Included { statsRescued++ }
		}
        if logProg != nil { logProg.SetValue(float64(i+1)) }
        if logProgLbl != nil { logProgLbl.SetText(fmt.Sprintf("%d/%d", i+1, total)) }
	}
	appendLogLine(a, "ALL: completed")
}
