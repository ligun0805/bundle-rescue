package main

import (
	"bufio"
	"context"
	"fmt"
	"math/big"
	"os"
	"strings"
	"syscall"

	"github.com/joho/godotenv"

	"golang.org/x/term"

	"github.com/ethereum/go-ethereum"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/core/types"
	"github.com/ethereum/go-ethereum/crypto"
	"github.com/ethereum/go-ethereum/ethclient"

	core "github.com/ligun0805/bundle-rescue/internal/bundlecore"
)

func main() {
	_ = godotenv.Load()
	_ = godotenv.Overload(".env.local")

	ctx := context.Background()

	rpc := getenv("RPC_URL", "https://eth.llamarpc.com")
	chainIDStr := getenv("CHAIN_ID", "")
	relays := getenv("RELAYS", "https://relay.flashbots.net")
	authPK := getenv("FLASHBOTS_AUTH_PK", "")
	safePK := getenv("SAFE_PRIVATE_KEY", "")
	blocks := atoi(getenv("BLOCKS", "6"), 6)
	tipGwei := atoi64(getenv("TIP_GWEI", "3"), 3)
	tipMul := atof(getenv("TIP_MUL", "1.25"), 1.25)
	baseMul := atoi64(getenv("BASEFEE_MUL", "2"), 2)
	bufferPct := atoi64(getenv("BUFFER_PCT", "5"), 5)

	ec, err := ethclient.Dial(rpc)
	must(err, "dial RPC")
	var chainID *big.Int
	if chainIDStr != "" {
		chainID = mustBig(chainIDStr)
	} else {
		chainID, err = ec.ChainID(ctx); must(err, "chain id")
	}

	if strings.TrimSpace(safePK) == "" { die("SAFE_PRIVATE_KEY is empty in env") }
	safeAddr := mustAddrFromPK(safePK)
	safeBal, _ := ec.BalanceAt(ctx, safeAddr, nil)

	fmt.Println("=== CONFIG (.env) ===")
	fmt.Println("RPC_URL           :", rpc)
	fmt.Println("CHAIN_ID          :", chainID.String())
	fmt.Println("RELAYS            :", relays)
	fmt.Println("FLASHBOTS_AUTH_PK :", maskHex(authPK))
	fmt.Println("SAFE_PRIVATE_KEY  :", maskHex(safePK))
	fmt.Println("  -> Safe address :", safeAddr.Hex())
	fmt.Println("  -> Safe balance :", formatEther(safeBal), "ETH")
	fmt.Println("Blocks            :", blocks)
	fmt.Println("Tip (gwei)        :", tipGwei)
	fmt.Println("TipMul            :", tipMul)
	fmt.Println("BaseFeeMul        :", baseMul)
	fmt.Println("BufferPct         :", bufferPct)
	fmt.Println("=====================")

	reader := bufio.NewReader(os.Stdin)

	for {
		fmt.Println("\n--- Ввод пары (compromised -> token -> amount -> to) ---")

		fromPK := readPassword("Введите приватный ключ скомпрометированного адреса: ")
		fromAddr := mustAddrFromPK(fromPK)
		fromBal, _ := ec.BalanceAt(ctx, fromAddr, nil)
		fmt.Println("  from:", fromAddr.Hex(), " | ETH balance:", formatEther(fromBal))

		token := readLine(reader, "Введите адрес ERC20 токена: ")
		if !common.IsHexAddress(token) { fmt.Println("  [!] Некорректный адрес токена"); continue }
		tokenAddr := common.HexToAddress(token)

		dec, err := fetchTokenDecimals(ctx, ec, tokenAddr)
		if err != nil { fmt.Println("  [!] Ошибка decimals:", err); continue }
		known, paused, _ := fetchPaused(ctx, ec, tokenAddr)
		if known && paused {
			fmt.Println("  [X] Токен в состоянии PAUSED — переход к следующему")
			continue
		}
		bal, err := fetchTokenBalance(ctx, ec, tokenAddr, fromAddr)
		if err != nil { fmt.Println("  [!] Ошибка чтения баланса токена:", err); continue }
		fmt.Println("  Decimals:", dec, " | TokenBalance(from):", formatTokensFromWei(bal, dec))

		amountTok := readLine(reader, "Введите amount (в токенах): ")
		amountWei, err := toWeiFromTokens(amountTok, dec)
		if err != nil { fmt.Println("  [!] Ошибка amount:", err); continue }
		if bal.Cmp(amountWei) < 0 {
			fmt.Println("  [X] Баланс меньше, чем amount — переход к следующему")
			continue
		}

		to := readLine(reader, "Введите адрес получателя: ")
		if !common.IsHexAddress(to) { fmt.Println("  [!] Некорректный адрес получателя"); continue }
		toAddr := common.HexToAddress(to)

		fmt.Println("\nВыберите опцию:")
		fmt.Println("  1) simulate")
		fmt.Println("  2) rescue")
		fmt.Println("  3) back (ввести другой токен/ключ)")
		choice := readLine(reader, "Ваш выбор [1/2/3]: ")
		choice = strings.TrimSpace(choice)
		if choice == "3" { continue }
		simOnly := (choice == "1")

		params := core.Params{
			RPC: rpc, ChainID: chainID, Relays: splitCSV(relays), AuthPrivHex: authPK,
			Token: tokenAddr, From: fromAddr, To: toAddr,
			AmountWei: amountWei, SafePKHex: safePK, FromPKHex: fromPK,
			Blocks: blocks, TipGweiBase: tipGwei, TipMul: tipMul, BaseMul: baseMul, BufferPct: bufferPct,
			SimulateOnly: simOnly, SkipIfPaused: true,
			Logf: func(f string, a ...any){ fmt.Printf(f+"\n", a...) },
			OnSimResult: func(relay, raw string, ok bool, err string){
				state := "OK"; if !ok { state = "FAIL" }
				fmt.Printf("  [sim %s] %s err=%s\n", relay, state, err)
				if len(raw) > 0 && len(raw) < 16_000 {
					fmt.Println("   raw:", truncate(raw, 4096))
				}
			},
		}

		res, err := core.Run(ctx, ec, params)
		if err != nil {
			fmt.Println("[ERROR]", err)
		} else {
			fmt.Println("[RESULT]", res.Reason, "| included:", res.Included)
		}

		again := strings.ToLower(readLine(reader, "Продолжить? [y/N]: "))
		if again != "y" && again != "yes" && again != "д" && again != "да" { break }
	}
}

func getenv(k, d string) string { v := strings.TrimSpace(os.Getenv(k)); if v=="" { return d }; return v }
func atoi(s string, d int) int { var n int; _,err := fmt.Sscan(strings.TrimSpace(s), &n); if err!=nil { return d }; return n }
func atoi64(s string, d int64) int64 { var n int64; _,err := fmt.Sscan(strings.TrimSpace(s), &n); if err!=nil { return d }; return n }
func atof(s string, d float64) float64 { var n float64; _,err := fmt.Sscan(strings.TrimSpace(s), &n); if err!=nil { return d }; return n }
func must(err error, msg string) { if err!=nil { die(msg+": "+err.Error()) } }
func die(msg string) { fmt.Fprintln(os.Stderr, msg); os.Exit(1) }
func splitCSV(s string) []string { arr := strings.Split(s, ","); out := make([]string,0,len(arr)); for _,x := range arr { x=strings.TrimSpace(x); if x!="" { out=append(out,x) } }; return out }
func mustBig(s string) *big.Int { z,newOk := new(big.Int), false; s=strings.TrimSpace(s); if strings.HasPrefix(s,"0x") { z,newOk = z.SetString(s[2:],16) } else { z,newOk = z.SetString(s,10) }; if !newOk { return big.NewInt(0) }; return z }
func maskHex(h string) string { h=strings.TrimSpace(h); if len(h)<=10 { return "***" }; return h[:6]+"…"+h[len(h)-4:] }

func mustAddrFromPK(pkHex string) common.Address {
	h := strings.TrimPrefix(strings.TrimSpace(pkHex), "0x")
	prv, err := crypto.HexToECDSA(h); must(err, "bad private key")
	return crypto.PubkeyToAddress(prv.PublicKey)
}

func formatEther(v *big.Int) string {
	if v==nil { return "0" }
	s := new(big.Rat).SetFrac(v, big.NewInt(1_000_000_000_000_000_000))
	return s.FloatString(6)
}

func truncate(s string, n int) string { if len(s)<=n { return s }; return s[:n] + "…(truncated)" }

func readLine(r *bufio.Reader, prompt string) string {
	fmt.Print(prompt)
	t, _ := r.ReadString('\n')
	return strings.TrimSpace(t)
}

func readPassword(prompt string) string {
	fmt.Print(prompt)
	b, err := term.ReadPassword(int(syscall.Stdin))
	fmt.Println()
	if err != nil { die("failed to read password: "+err.Error()) }
	return strings.TrimSpace(string(b))
}

// ERC20 helpers mirrored locally

func fetchTokenDecimals(ctx context.Context, ec *ethclient.Client, token common.Address) (int, error) {
	data := common.FromHex("0x313ce567") // decimals()
	res, err := ec.CallContract(ctx, ethereum.CallMsg{To: &token, Data: data}, nil)
	if err != nil { return 0, err }
	if len(res)==0 { return 18, nil }
	return int(res[len(res)-1]), nil
}

func fetchTokenBalance(ctx context.Context, ec *ethclient.Client, token, owner common.Address) (*big.Int, error) {
	data := append(common.FromHex("0x70a08231"), common.LeftPadBytes(owner.Bytes(),32)...)
	res, err := ec.CallContract(ctx, ethereum.CallMsg{To: &token, Data: data}, nil)
	if err != nil { return nil, err }
	if len(res)==0 { return big.NewInt(0), nil }
	return new(big.Int).SetBytes(res), nil
}

var pausedSigs = [][]byte{
	common.FromHex("0x5c975abb"), // paused()
	common.FromHex("0x3f4ba83a"), // isPaused()
	common.FromHex("0x51dff989"), // transfersPaused()
	common.FromHex("0x5c701d2f"), // tradingPaused()
	common.FromHex("0x8462151c"), // isTradingPaused()
	common.FromHex("0x2e1a7d4d"), // pausedTransfers()
	common.FromHex("0x0b3bafd6"), // globalPaused()
	common.FromHex("0x9c6a3b7c"), // transferEnabled()
	common.FromHex("0x75f12b21"), // isTransferEnabled()
	common.FromHex("0x4f2be91f"), // tradingEnabled()
	common.FromHex("0x0dfe1681"), // isTradingEnabled()
}

func fetchPaused(ctx context.Context, ec *ethclient.Client, token common.Address) (known bool, value bool, err error) {
	for _, sig := range pausedSigs {
		res, e := ec.CallContract(ctx, ethereum.CallMsg{To: &token, Data: sig}, nil)
		if e != nil || len(res)==0 { continue }
		b := res[len(res)-1]
		hexSig := fmt.Sprintf("%x", sig)
		if strings.Contains(hexSig, "enabled") {
			return true, b == 0, nil
		}
		return true, b == 1, nil
	}
	return false, false, nil
}

func toWeiFromTokens(amount string, decimals int) (*big.Int, error) {
	amount = strings.TrimSpace(amount)
	if amount == "" { return nil, fmt.Errorf("empty amount") }
	if decimals < 0 { decimals = 18 }
	parts := strings.SplitN(amount, ".", 2)
	intPart := parts[0]; fracPart := ""
	if len(parts) == 2 { fracPart = parts[1] }
	if len(fracPart) > decimals { return nil, fmt.Errorf("too many fractional digits for %d decimals", decimals) }
	fracPart = fracPart + strings.Repeat("0", decimals-len(fracPart))
	clean := strings.TrimLeft(intPart+fracPart, "0")
	if clean == "" { return big.NewInt(0), nil }
	v, ok := new(big.Int).SetString(clean, 10)
	if !ok { return nil, fmt.Errorf("bad amount") }
	return v, nil
}

func formatTokensFromWei(v *big.Int, decimals int) string {
	if v==nil { return "0" }
	if decimals<=0 { return v.String() }
	s := new(big.Int).Abs(v).String()
	neg := v.Sign() < 0
	if len(s) <= decimals {
		frac := strings.Repeat("0", decimals-len(s)) + s
		out := "0." + strings.TrimRight(frac, "0")
		if out == "0." { out = "0" }
		if neg { return "-" + out }
		return out
	}
	intPart := s[:len(s)-decimals]
	frac := strings.TrimRight(s[len(s)-decimals:], "0")
	out := intPart
	if frac != "" { out = intPart + "." + frac }
	if neg { return "-" + out }
	return out
}

var _ = types.LatestSignerForChainID
